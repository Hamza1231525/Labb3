package com.example;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {

    private static final String DB_NAME = "labb3";
    private static final String USER = "root";
    private static final String PASSWORD = System.getenv("DB_PASSWORD");

    private static final String URL =
            "jdbc:mysql://localhost:3306/" + DB_NAME +
                    "?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

    public static void main(String[] args) {
        insertPerson("Anna", "Svensson", Date.valueOf("1995-04-12"), 32000.50);
        printAllPersons();
    }

    private static void insertPerson(String firstName, String lastName, Date dob, double income) {
        String sql = "INSERT INTO person (first_name, last_name, dob, income) VALUES (?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, firstName);
            stmt.setString(2, lastName);
            stmt.setDate(3, dob);
            stmt.setDouble(4, income);

            int rows = stmt.executeUpdate();
            System.out.println("Rader insatta: " + rows);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void printAllPersons() {
        String sql = "SELECT * FROM person";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String firstName = rs.getString("first_name");
                String lastName = rs.getString("last_name");
                Date dob = rs.getDate("dob");
                double income = rs.getDouble("income");

                System.out.println(
                        "ID: " + id +
                                ", Förnamn: " + firstName +
                                ", Efternamn: " + lastName +
                                ", Född: " + dob +
                                ", Inkomst: " + income
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}